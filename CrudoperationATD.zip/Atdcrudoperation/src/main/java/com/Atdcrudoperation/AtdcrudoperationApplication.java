package com.Atdcrudoperation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AtdcrudoperationApplication {

	public static void main(String[] args) {
		SpringApplication.run(AtdcrudoperationApplication.class, args);
		System.err.println("Crud Operation");
	}

}

// In this project i have used following dependencies
//1.Spring web      ---------->tomacat server
//2.Spring devtools ---------->To auto integrate
//3.JPA          ------------->To call hibernate properties
//4.MySQL Driver ------------->To connect with MYsql query browser


// MYSQL query browser
//Database Name---------> atd
//Table Name------------> student



//annotations used ------------------------->

//1.Restcontroller
//2.Autowired
//3.@postmapping
//4.@getmapping
//5.@putmappting
//6.@deletemapping
//7.@pathvariable
//8.@RequestBody