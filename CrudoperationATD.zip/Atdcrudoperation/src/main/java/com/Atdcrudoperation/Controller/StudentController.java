package com.Atdcrudoperation.Controller;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.Atdcrudoperation.Model.Student;

@RestController                                             //to start the tomcat server & control class
public class StudentController {
	
	@Autowired                                               //to create object
	SessionFactory sf;
	
	@PostMapping("/insert")                                 //to insert data into database
	public Student toIns(@RequestBody Student s1) {         //reqbody--->to insert data from body
		Session ss=sf.openSession();
		Transaction tx=ss.beginTransaction();
		ss.save(s1);
		tx.commit();
		System.out.println(s1);
		return s1;
	}
	
	
	@PutMapping("/update")                               //to update data into database          
	public Student toUpdate(@RequestBody Student s1) {
		Session ss=sf.openSession();
		Transaction tx=ss.beginTransaction();
		ss.update(s1);
		tx.commit();
		System.out.println(s1);
		return s1;
	}
	
	@DeleteMapping("/delete/{id}")
	public Student toDelete(@PathVariable int id) {      //Pathvariable---->to delete data through api
		Session ss=sf.openSession();
		Transaction tx=ss.beginTransaction();
		Student s1=ss.load(Student.class, id);
		ss.delete(s1);
		tx.commit();
		System.out.println(s1);
		return s1;
	}
	
	
	
	
	@GetMapping("/getstu")                              //to get data from database
	public List<Student> togetStudent() {
		Session ss=sf.openSession();
		Transaction tx=ss.beginTransaction();
		
		Criteria cr1=ss.createCriteria(Student.class);        //i applied criteria here
		cr1.add(Restrictions.ilike("city", "Mumbai"));             //Restriction method i.e  (ilike)
		List<Student> k46=cr1.list();                         //i use List here
		k46.forEach(System.out::println);                     //for printing on console i use here---------->foreach loop
		return k46;
	}
	
	
	
	
	@GetMapping("/getall")
	public List<Student> Togetall() {
		Session ss=sf.openSession();
		Transaction tx=ss.beginTransaction();
		
		Query query=ss.createQuery("from Student");         //i use here Query to get all
		List<Student> k45=query.list();
		k45.forEach(System.out::println);
		return k45;
	}
	
	@GetMapping("/getmca")                              //to get data from database
	public List<Student> togetStudentmca() {
		Session ss=sf.openSession();
		Transaction tx=ss.beginTransaction();
		
		Criteria cr1=ss.createCriteria(Student.class);        //i applied criteria here
		cr1.add(Restrictions.like("stream", "MCA"));           //Restriction method ---->like method
		List<Student> k46=cr1.list();                         //i use List here
		k46.forEach(System.out::println);                     //for printing on console i use here---------->foreach loop
		return k46;
	}
	
	
	
	

}
