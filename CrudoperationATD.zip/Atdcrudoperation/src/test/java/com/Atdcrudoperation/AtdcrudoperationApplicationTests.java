package com.Atdcrudoperation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AtdcrudoperationApplicationTests {

	@Test
	void contextLoads() {
	}

}
